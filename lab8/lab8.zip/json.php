<?php

$string = file_get_contents("test.json");
$json_a = json_decode($string, true);

$a1 = $json_a['response'];
$a2 = $a1['data'];
$a3 = $a2['item'];
$a4 = $a3['track'];


echo "<body>";
echo "<div style='border-radius: 5px; border-style: solid; font-family: sans-serif; text-align: center; background-color: #DB7093; width: 700px; margin-left: auto; margin-right: auto;'>";
echo "<h2> Hawaiian Music with JSON</h2>";
echo $a4['artist'] . "<br>";
echo  $a4['album']  . "<br>";
echo  $a4['title'] . "<br>";
echo "<img src=";
echo  $a4['imageurl'] ;
echo " style='width: 20%;height: 20%;'>";
echo "</div>";
echo "</body>";

?>
